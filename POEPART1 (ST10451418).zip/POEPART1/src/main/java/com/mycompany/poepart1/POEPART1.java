/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poepart1;

/**
 *
 * @author tokol
 */
import java.util.Scanner;

public class POEPART1 {
    public static void main(String[] args) {
        Scanner scanner;
        scanner = new Scanner(System.in);
        
        String username = "";
        String password = "";
        String firstName = "";
        String lastName ="";
        
        //account creation
        System.out.println("HEY!");
        System.out.println("WELCOME TO YOUR ACCOUNT CREATION,PLEASE FILL YOUR DETAILS BELOW");
        
        //Enter username
        while (username.length() < 6 || !username.contains ("_")){
            System.out.print("Enter username: ");
            username = scanner.nextLine();
            if (username.length() < 6 ) {
            System.out.println("Username must be at least 6 characters long.");
            }
            else if(!username.contains("_")){
            System.out.println("Username must contain an underscore.");
            }
        }
        //Enter password
        while (password.length() < 8){
            System.out.print("Enter password: ");
            password = scanner.nextLine();
            if (password.length() < 8) {
            System.out.println("Password must be at least 8 characters long.");
            }
        } 
        //Enter first name
        while (firstName.isEmpty()){
            System.out.print("Enter first name: ");
            firstName = scanner.nextLine();
            if (firstName.isEmpty()){
                System.out.println("First name cannot be empty.");
                }
            }
        //Enter last name
        while (lastName.isEmpty()){
        System.out.print("Enter last name: ");
        lastName = scanner.nextLine();
        if (lastName.isEmpty()){
            System.out.println("Last name cannot be empty.");
            }
        }
        //Showing results
            System.out.println("Account created successfully!");
            System.out.println("Username: " + username);
            System.out.println("Password: " + password);
            System.out.println("First Name: " + firstName);
            System.out.println("Last Name: " + lastName);
            
        // Login 
        System.out.println("\nLOGIN:");
        String loginUsername = "";
        String loginPassword = "";
        
        //Enter login username
        while (!loginUsername.equals(username)){
            System.out.print("Enter username to login: ");
            loginUsername = scanner.nextLine();
            if (!loginUsername.equals(username)){
                System.out.println("Username incorrect. Please try again!");
            }
        }    
        //Enter login password
        while (!loginPassword.equals(password)){
            System.out.print("Enter password to login: ");
            loginPassword = scanner.nextLine();
            if (!loginPassword.equals(password)){
                System.out.println("Password incorrect. Please try again!");
            }
        }
        //if everything is right
         if (loginUsername.equals(username) || loginPassword.equals(password)){
            System.out.println("Login successful. Username and Password enter correctly.");
        }

        scanner.close();
    }
}